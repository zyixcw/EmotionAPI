using EmotionDetectionAPI.Services;
using EmotionDetectionAPI.Controllers;
using Microsoft.AspNetCore.Mvc;

var builder = WebApplication.CreateBuilder(args);

// Ajouter des services au conteneur.
builder.Services.AddSingleton<EmotionDetectionService>();  // Enregistre ton service

// Ajouter les services de contrôleur API
builder.Services.AddControllers();

// Configurer CORS pour autoriser toutes les origines
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll",
        policy => policy
            .AllowAnyOrigin()    // ✅ Autorise toutes les origines
            .AllowAnyMethod()    // ✅ Autorise toutes les méthodes HTTP (GET, POST, etc.)
            .AllowAnyHeader());  // ✅ Autorise tous les headers
});

var app = builder.Build();

// Configurer le pipeline de requêtes HTTP
app.UseHttpsRedirection();

// Activer CORS avant de mapper les contrôleurs
app.UseCors("AllowAll");

// Ajouter la route pour la détection d'émotion
app.MapControllers();

app.Run();
