using System.Diagnostics;
using System.Threading.Tasks;

namespace EmotionDetectionAPI.Services
{
    public class EmotionDetectionService
    {
        public async Task<string> DetectEmotionAsync(string message)
        {
            var startInfo = new ProcessStartInfo
            {
                FileName = "cmd.exe",
                Arguments = $"/C ollama run mistral \"Quelle est l'�motion de ce texte : '{message}' ?\"",
                RedirectStandardOutput = true,
                UseShellExecute = false,
                CreateNoWindow = true
            };

            using (var process = Process.Start(startInfo))
            using (var reader = process?.StandardOutput)
            {
                if (reader != null)
                {
                    var result = await reader.ReadToEndAsync();
                    return result.Trim();
                }
                return "Erreur : Aucun r�sultat retourn�";
            }
        }
    }
}
