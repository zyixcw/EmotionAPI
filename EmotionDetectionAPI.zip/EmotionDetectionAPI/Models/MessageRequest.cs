namespace EmotionDetectionAPI.Models
{
    public class MessageRequest
    {
        public required string Text { get; set; }
    }
}
