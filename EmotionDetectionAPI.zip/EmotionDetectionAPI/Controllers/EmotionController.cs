using EmotionDetectionAPI.Services;
using EmotionDetectionAPI.Models;
using Microsoft.AspNetCore.Mvc;

namespace EmotionDetectionAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EmotionController : ControllerBase
    {
        private readonly EmotionDetectionService _emotionDetectionService;

        public EmotionController(EmotionDetectionService emotionDetectionService)
        {
            _emotionDetectionService = emotionDetectionService;
        }

        [HttpPost("detect-emotion")]
        public async Task<IActionResult> DetectEmotion([FromBody] MessageRequest request)
        {
            if (string.IsNullOrEmpty(request.Text))
                return BadRequest("Le texte ne peut pas être vide.");

            var emotion = await _emotionDetectionService.DetectEmotionAsync(request.Text);
            return Ok(new { emotion });
        }
    }
}
